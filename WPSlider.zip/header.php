<!-- HEADER.PHP BELOW -->


<div id='header'>
	<div id='logoContainer'>
			<div id='logo'></div>
	</div>
		<!--img id='logo' src="<?php bloginfo('template_directory'); ?>/assets/logo.png"-->
	<div id='pageTitle-navContainer'>
		<div id='pageTitleContainer'>
			<div id='pageTitle'>
				<h1>WORDPRESS</h1><h1>SLIDER</h1>		
			</div>
			<div class='line'></div>		
		</div>
		<div id='navigationContainer'>
			<div id='contactMenu'>
				<ul>
					<li class='navLink navLinkBasic'>home</li>
					<li class='navLink navLinkBasic'>about</li>
					<li class='navLink navLinkBasic'>products</li>
					<li class='navLink navLinkBasic'>contact</li>
				</ul>
			</div>
			
		</div>
	</div>
	<div id='contactLinksContainer'>
		<div id='contactLinks'>
			<ul>
				<li class='icon'>
					<img src="<?php bloginfo('template_directory'); ?>/assets/MailIcon.jpg" height='20px'>
				</li>
				<!--li class='icon'>
					<img src="<?php bloginfo('template_directory'); ?>/assets/GoogleIcon.jpg" height='20px'>
				</li-->
				<li class='icon'>
					<img src="<?php bloginfo('template_directory'); ?>/assets/FacebookIcon.jpg" height='20px'>
				</li>
				<li class='icon'>
					<img src="<?php bloginfo('template_directory'); ?>/assets/TwitterIcon.jpg" height='20px'>
				</li>
			</ul>
		</div>
	</div>
</div>
