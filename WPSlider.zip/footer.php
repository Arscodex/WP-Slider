<!-- FOOTER.PHP BELOW -->

<div id="footer">
	<div id='footerContent'>
		<div id='footerLinks'>
			<div class='footerColumn'>
				<div>About</div></br>
				<div>History</div></br>
			</div>
			<div class='footerColumn'>
				<div>Products</div></br>
				<div>Logos</div></br>
			</div>
			<div class='footerColumn'>
				<div>Contact</div></br>
				<div>Mail</div></br>
			</div>
		</div>
	</div>	
</div>

